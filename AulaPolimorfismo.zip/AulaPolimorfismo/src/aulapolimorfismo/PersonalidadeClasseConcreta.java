package aulapolimorfismo;

/**
 *
 * @author ranie
 */
public class PersonalidadeClasseConcreta {
    
    public String falar(){
        
        return "";
    }
    
    public void acionarFalar(PersonalidadeClasseConcreta obj){
        
        System.out.println(obj.falar());
    }
        
}
